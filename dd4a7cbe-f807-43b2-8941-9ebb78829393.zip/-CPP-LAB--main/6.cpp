#include<iostream>
using namespace std;

int main(){

    int x = 10;
    float y = static_cast<float>(x);
    cout<<"float value of y is: "<<y<<endl;

return 0;
}