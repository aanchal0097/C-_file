#include<iostream>
using namespace std;

int main(){

    int x,y,addition,subtraction,multiplication,division;
    cout<<"Enter the value of x and y: ";
    cin>>x>>y;

    addition=x+y;
    subtraction=x-y;
    multiplication=x*y;
    division=x/y;

    cout<<"Addition: "<<addition<<endl;
    cout<<"Subtraction: "<<subtraction<<endl;
    cout<<"Multiplication: "<<multiplication<<endl;
    cout<<"Division: "<<division<<endl;

return 0;
}